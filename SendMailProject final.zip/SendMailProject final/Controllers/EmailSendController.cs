﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Mydummyproject.Models;
using Mydummyproject.Sevices;

namespace Mydummyproject.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class EmailSendController : ControllerBase
    {
        EmailService es = new EmailService();

        [HttpPost]
        public ActionResult<ResponceModel> SendMail(EmailClass ec)
        {
            try
            {
                
                string[] MulEmails = ec.Email;
                MailMessage message = new MailMessage(); 
                message.From = new MailAddress("Sathyabtech420@gmail.com");
                foreach (var Email in MulEmails)
                {
                    message.To.Add(Email);
                }
                //message.To.Add(to);
                message.Subject = "Device data";
                message.Body = es.getHtml(ec.Body);//getHtml(ec.Body);
                message.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                smtp.UseDefaultCredentials = false;
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Credentials = new NetworkCredential("sathyabtech420@gmail.com", "Sathya@123");
                smtp.Send(message);
                return new ResponceModel() { Status= "Sucessfull", Message="Mail Sent sucessfully" };
            }
            catch (Exception ex)
            {
              
                return new ResponceModel() { Status = "Falid", Message = ex.Message}; ;
                
            } 
        }

       
    }
}