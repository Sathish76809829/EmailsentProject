﻿using Mydummyproject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mydummyproject.Sevices
{
    public class EmailService
    {
        public string getHtml(List<DataModel> table1)
        {
            try
            {
               
                string fullTable = null;
                string paragraph = "<p><b> Hey! the following devices got inactive.</b></p>";
                fullTable += paragraph;
                string header = "<table border='1'style='border-collapse:collapse'><tr><th> DeviceName </th> <th> Location </th><th> Status </th> <th> time </th ></tr >";
                fullTable += header;
                string TableContaint = string.Empty;

                foreach (var item in table1)
                {
                    TableContaint = $"<tr><td> {item.DeviceName} </td> <td> {item.Location} </td><td> {item.Status} </td><th> {item.Time}</th>  </tr> ";
                    fullTable += TableContaint;
                }
                string endtable = "</table>";

                fullTable += endtable;
                string regards = "<p><b>Regards,<br>Elpis It Solutions Pvt Ltd.</b></p>";
                fullTable += regards;


                return fullTable;
            }
            catch (Exception)
            {
                return null;
                throw;
            }
        }
    }
}
