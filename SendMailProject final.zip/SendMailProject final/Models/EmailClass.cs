﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mydummyproject.Models
{
    public class EmailClass
    {
        public string From { get; set; }
        public string[] Email { get; set; }
        //public string To = "sathyabech420@gmail.com";
        public string Subject { get; set; }
        public List<DataModel> Body { get; set; }
    }
}
