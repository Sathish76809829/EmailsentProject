﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mydummyproject.Models
{
    public class ResponceModel
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
