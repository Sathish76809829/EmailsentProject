﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mydummyproject.Models
{
    public class DataModel
    {
        public string DeviceName { get; set; }
        public string Location { get; set; }
        public string Status { get; set; }
        public DateTime Time { get; set; }
    }
}
